let spinnerActionCreators = {
	increment(){
		return {type : 'INCREMENT'};
	},
	decrement(){
		return {type : 'DECREMENT'};
	}
};
export default spinnerActionCreators;