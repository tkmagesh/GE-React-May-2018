export function toggle(bugToToggle){
	return { type : 'TOGGLE', payload : bugToToggle };
}