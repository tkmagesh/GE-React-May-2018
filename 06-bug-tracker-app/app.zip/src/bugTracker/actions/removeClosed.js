export function removeClosed(){
	return { type : 'REMOVE_CLOSED' };
}