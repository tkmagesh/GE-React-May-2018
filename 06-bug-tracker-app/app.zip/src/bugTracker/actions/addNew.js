export function addNew(bugName){
	return { type : 'ADD_NEW', payload : bugName };
}